package com.tenisme.cloudcontacts.util;

public class Util {
    public static final String KEY_COLLECTION = "Contacts";
    public static final String KEY_ID = "id_";
    public static final String KEY_NAME = "name";
    public static final String KEY_PHONE_NUMBER = "phoneNumber";
}
